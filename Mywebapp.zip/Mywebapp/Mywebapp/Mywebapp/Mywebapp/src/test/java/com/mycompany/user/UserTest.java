package com.mycompany.user;

import org.junit.jupiter.api.Test;

class UserTest {

    @Test
    void getId() {
    }

    @Test
    void setId() {
    }

    @Test
    void getName() {
    }

    @Test
    void setname() {
    }

    @Test
    void testToString() {
    }
}